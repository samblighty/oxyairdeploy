const fs = require('fs');
const MongoClient = require('mongodb').MongoClient;

// const DBURL = "mongodb+srv://oxyair:oxyair@cluster0-ltuj9.mongodb.net/test?retryWrites=true&w=majority";
const DBURL = "mongodb+srv://OxyAir:oxyair@oxyair-zd5vf.gcp.mongodb.net/OxyAir?retryWrites=true&w=majority";

(async function() {
	const file = fs.readFileSync('./oxy.json', { encoding: 'utf8' });
	const json = JSON.parse(file);

	const client = new MongoClient(DBURL, { useNewUrlParser: true });
	await client.connect();

	const res = await client.db('OxyAir').collection('OxyAir').insertMany(json);

	console.log(res);
})();