var MongoClient = require('mongodb').MongoClient;
var url = "mongodb+srv://OxyAir:oxyair@oxyair-zd5vf.gcp.mongodb.net/OxyAir?retryWrites=true&w=majority";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("OxyAir");
  var query = { airlinename: "Air Canada" };
  dbo.collection("OxyAir").find(query).toArray(function(err, result) {
    if (err) throw err;
    console.log(result);
    db.close();
  });
});