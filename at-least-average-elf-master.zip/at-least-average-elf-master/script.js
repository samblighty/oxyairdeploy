const originalTable = document.getElementById("table");

var data = null;

var xhr = new XMLHttpRequest();
xhr.withCredentials = true;

var gethr = new XMLHttpRequest();
gethr.withCredentials = true;

if (window.XMLHttpRequest) {
            // code for IE7+, Firefox, Chrome, Opera, Safari
            var phpchr = new XMLHttpRequest();
			
        } else 
        {
            // code for IE6, IE5
            var phpchr = new ActiveXObject("Microsoft.XMLHTTP");
        }

xhr.addEventListener("readystatechange", function () {
	if (this.readyState === this.DONE) {
		//Create Json
		json = JSON.parse(this.responseText);
		console.log(json);
		
		//Get Cheapest Carrier ID
		var QuoteArray = []
		//Get the quote prices
		for (var i = 0; i < json.Quotes.length; i++){
			var QuoteArrayBuilder = [];
			//For each Quote
			//Get the Carrier ID
			var carrierId = json.Quotes[i].OutboundLeg.CarrierIds[0];
			var carrierName = "";

			// Loop to get the name of the carrier from id
			for (var j = 0; j<json.Carriers.length; j ++){
				var temp = (json.Carriers[j].CarrierId)
				if (temp == carrierId){
					console.log("Yes");
					carrierName = json.Carriers[j].Name;
				}
			}
			
			QuoteArrayBuilder = [carrierName,json.Quotes[i].MinPrice,json.Quotes[i].OutboundLeg.DepartureDate];
			
			QuoteArray.push(QuoteArrayBuilder);
			
		}
		displayTable(QuoteArray);	
		document.getElementById("output").style.display="block";	

	}
});

gethr.addEventListener("readystatechange", function () {
	if (this.readyState === this.DONE) {
		//Create Json
		json = JSON.parse(this.responseText);
		console.log(json);
		
		//Get Cheapest Carrier ID
		var LocationArray = []
		//Get the quote prices
		for (var i = 0; i < json.Places.length; i++){
			var LocationArrayBuilder = [];
			//For each Quote
			//Get PlaceId
			var PlaceId = json.Places[i].PlaceId;
			var PlaceName = json.Places[i].PlaceName;
			LocationArrayBuilder = [PlaceId, PlaceName]
			LocationArray.push(LocationArrayBuilder);
		}
		displayAirportTable(LocationArray);	
		document.getElementById("output").style.display="block";	
	}
});

function onSearch(){
	document.getElementById("table").innerHTML = originalTable;
	//Build the query
	var stringBuilder = "https://skyscanner-skyscanner-flight-search-v1.p.rapidapi.com/apiservices/browsequotes/v1.0/UK/"

	

	stringBuilder += "GBP/en-UK/" +
	document.getElementById("origin").value+"-sky/" + 
	document.getElementById("destination").value+"-sky/" + 
	document.getElementById("outbound").value ;
	console.log(stringBuilder);

	
	
	xhr.open("GET", stringBuilder);
	xhr.setRequestHeader("x-rapidapi-host", "skyscanner-skyscanner-flight-search-v1.p.rapidapi.com");
	xhr.setRequestHeader("x-rapidapi-key", "ebec90ce0bmshfe1c45e6857a67cp1d801fjsn0c31fc2364d3");

	xhr.send(data);
}

function onSearchForAirports(){
	document.getElementById("table").innerHTML = originalTable;
	

	var stringBuilder = "https://skyscanner-skyscanner-flight-search-v1.p.rapidapi.com/apiservices/autosuggest/v1.0/" +document.getElementById("CurrentLocation").value + "/GBP/en-GB/?query=" + document.getElementById("outbound").value +"\"" ;

	
	console.log(stringBuilder);

	gethr.open("GET", stringBuilder);
	gethr.setRequestHeader("x-rapidapi-host", "skyscanner-skyscanner-flight-search-v1.p.rapidapi.com");
	gethr.setRequestHeader("x-rapidapi-key", "ebec90ce0bmshfe1c45e6857a67cp1d801fjsn0c31fc2364d3");

	gethr.send(data);

}

function displayTable(data){
	var table = document.getElementById("table");

	var rowOne = table.insertRow();
	var nameCell = rowOne.insertCell()
	var priceCell = rowOne.insertCell();
	var dateCell = rowOne.insertCell();
	//var AirInfo = rowOne.insertCell();

	nameCell.innerHTML = "Carrier Name";
	priceCell.innerHTML = "Price (£)";
	dateCell.innerHTML = "Date";
	//AirInfo.innerHTML = "Air Info"

	for(var i = 1; i < data.length + 1; i++) {
		var row = table.insertRow();
		var newName = row.insertCell();
		var newPrice = row.insertCell();
		var newDate = row.insertCell();

		//var newAirInfo = row.insertCell();
		
		data[i-1][2] = data[i-1][2].substring(0, 10);

		//testPhpConnection(data[i-1][0],newAirInfo)

		newName.innerHTML = data[i-1][0]
		newPrice.innerHTML = data[i-1][1]
		newDate.innerHTML = data[i-1][2]
		//var row2 = table.insertRow();
		testPhpConnection(data[i-1][0], document.getElementById("airInfo"))


	}
}

function displayAirportTable(data) {
	var table = document.getElementById("table");	

	for (var i = 1; i < data.length + 1; i ++){
		var row = table.insertRow();
		var newName = row.insertCell();
		var newID = row.insertCell();

		newName.innerHTML = data[i-1][0];
		newID.innerHTML = data[i-1][1];
		
	}
}

function testPhpConnection(data,obj){
	
	phpchr.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			obj.innerHTML += this.responseText;
			return true;
		}
	};
	
	phpchr.open("GET","getOxygenData.php?q="+data,true); 
	//phpchr.setRequestHeader("");
	phpchr.send();
}

function toggleMenu() {
	var ele = document.getElementsByTagName('body')[0];
	if (!hasClass(ele, "open")) {
	  addClass(ele, "open");
	} else {
	  removeClass(ele, "open");
	}
  }

  function validateIATA(){
	var checkOne = document.getElementById("CurrentLocation").value;
	var checkTwo = document.getElementById("outbound").value;

	if(!checkOne || !checkTwo){
		alert("Missing input");
	} else if (/[^a-zA-Z]/.test(checkOne) || /[^a-zA-Z]/.test(checkTwo)) {
		alert("Invalid input - only A-Z");
	} else {
		onSearchForAirports();
	}
  }

  function validateLocation(){
	  var checkOne = document.getElementById("origin").value;
	  var checkTwo = document.getElementById("destination").value;

	  if(!checkOne || !checkTwo){
		  alert("Missing input");
	  } else if (/[^a-zA-Z]/.test(checkOne) || /[^a-zA-Z]/.test(checkTwo)) {
		  alert("Invalid input - only A-Z");
	  } else {
		  onSearch();
	  }
  }
