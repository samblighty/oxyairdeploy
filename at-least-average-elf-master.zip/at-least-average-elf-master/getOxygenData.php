<!DOCTYPE html>
<html>
<head>
        <title>European Lung Foundation</title> 
        <link rel="stylesheet" href="style.css" type="text/css">
        <script src="script.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
        <link href='https://fonts.googleapis.com/css?family=Archivo Narrow' rel='stylesheet'>
        <link href='htt ps://fonts.googleapis.com/css?family=Megrim' rel='stylesheet'>
        <link href="https://fonts.googleapis.com/css?family=Raleway:200,100,400" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">
    </head>
<body>
	<div class="tbl-header">
<?php
	
	
	openConnection();

	function openConnection(){
		$q = strval ($_GET['q']);
		$value = $q.trim();

		$con = new mysqli('mysql.cs.nott.ac.uk','psymsa','SQLDB','psymsa');

		if (!$con){
			die('Could not connect: ' . mysqli_error($con));
			echo"COULD NOT CONNECT";
	}

	$sql="SELECT * FROM `TABLE 3` WHERE `COL 2` = '$value'";
	$result = mysqli_query($con,$sql);

	echo "<br><table>
	<tr>
	<th>Name</th>
	<th>Email</th>
	<th>Phone</th>
	<th>Website</th>

	</tr>";

	while($row = mysqli_fetch_array($result)){
		echo "<tr>";
		echo "<td>" . $row['COL 2'] . "</td>";
		echo "<td>" . $row['COL 3'] . "</td>";
		//echo "<td>" . $row['COL 4'] . "</td>";
		echo "<td>" . $row['COL 5'] . "</td>";
		echo "<td>" . $row['COL 6'] . "</td>";
		echo "</tr>";

		$detail = $row['COL 4'];
	}
	
	echo "</table>";
	$detail = preg_replace('/[\x00-\x1F\x7F-\xFF]/', '<br>', $detail);
	$detail = preg_replace('/[,]/', '', $detail);
	echo "<p>$detail</p>";
	

}
mysqli_close($con);
?>
</div>

</body>
</html>