<!DOCTYPE html>
<meta charset="UTF-8">

<html>

<head>
    <title>European Lung Foundation</title>
    <link rel="stylesheet" href="style.css" type="text/css">
    <script src="script.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.css">
    <link href='https://fonts.googleapis.com/css?family=Archivo Narrow' rel='stylesheet'>
    <link href='htt ps://fonts.googleapis.com/css?family=Megrim' rel='stylesheet'>
    <link href="https://fonts.googleapis.com/css?family=Raleway:200,100,400" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Righteous" rel="stylesheet">

    
</head>


<body>
       
        

    <img src="OXYAir.png" />



    <div class="input">
        <form data-aos-duration="1000" data-aos="fade-up" id="form" class="topBefore">
            <h1 id="Contact" class="home-title" style=" margin-bottom:0;"><span>Inbound</span></h1>
            <input id="inbound" type="date" placeholder="INBOUND Date">

            <h1 id="Contact" class="home-title" style=" margin-bottom:0;"><span>Outbound</span></h1>
            <input id="outbound" type="date" placeholder="OUTBOUND Date">

            <h1 id="Contact" class="home-title" style=" margin-bottom:0;"><span>Origin</span></h1>
            <input id="origin" type="text" placeholder="Enter IATA Code">

            <h1 id="Contact" class="home-title" style=" margin-bottom:0;"><span>Destination</span></h1>
            <input id="destination" type="text" placeholder="Enter IATA Code">
            <a href="findAnAirport.html" class="button1 bouncy" style="animation-delay:0.07s">Search for IATA codes</a>

            <div style="padding-top: 65px;">
                <button type="button" onclick="validateLocation()" class="learn-more">
                    <div class="circle">
                        <span class="icon arrow"></span>
                    </div>
                    <p class="button-text">Search</p>
                </button>
            </div>
        </form>

    </div>


    <div id="output" style="display: none;">
        <form>
            <br>
            <table id="table">
            </table>
        </form>
    </div>
    <div id="airInfo"></div>

  
   
    
    


</body>

</html>