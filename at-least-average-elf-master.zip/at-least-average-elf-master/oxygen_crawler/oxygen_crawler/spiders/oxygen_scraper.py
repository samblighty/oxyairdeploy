# -*- coding: utf-8 -*-
import scrapy


class OxygenScraperSpider(scrapy.Spider):
    name = "quotes-toscrape"
    start_urls = ['https://www.europeanlung.org/en/lung-disease-and-information/air-travel/airline-index/',
    'https://www.europeanlung.org/en/lung-disease-and-information/air-travel/airline-index/?page=2',
    'https://www.europeanlung.org/en/lung-disease-and-information/air-travel/airline-index/?page=3',
    'https://www.europeanlung.org/en/lung-disease-and-information/air-travel/airline-index/?page=4',
    'https://www.europeanlung.org/en/lung-disease-and-information/air-travel/airline-index/?page=5',
    'https://www.europeanlung.org/en/lung-disease-and-information/air-travel/airline-index/?page=6',
    'https://www.europeanlung.org/en/lung-disease-and-information/air-travel/airline-index/?page=7',
    'https://www.europeanlung.org/en/lung-disease-and-information/air-travel/airline-index/?page=8',]

    def parse(self, response):
        for cf in response.css("li.cf"):
           yield {
                'airlinename': cf.css("h2 ::text").extract(),
                'phone': cf.css("li.phone ::text").extract(),
                'email': cf.css("li.email ::text").extract(),
                'website': cf.css("li.website ::text ").extract(),
                'oxygendetails': cf.css("div.details ::text").extract()
            }
       #next_page_url = response.css(" ul > li > a ::attr(href)").extract_first()
       # if next_page_url:
           # yield scrapy.Request(response.urljoin(next_page_url))
    
    
