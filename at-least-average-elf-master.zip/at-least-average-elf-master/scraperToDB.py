import pymysql.cursors
import pymysql

# Connect to the database
connection = pymysql.connect(host='mysql.cs.nott.ac.uk',
                             user='psyam22',
                             password='newpassword',
                             db='ELF',
                             charset='utf8mb4',
                             cursorclass=pymysql.cursors.DictCursor)

try:
    with connection.cursor() as cursor:
        # Create a new record
        sql = "INSERT INTO ELF VALUES (0,'RYANAIR','079990','sasasasas','asasasasasas','asasasasasas')"
        cursor.execute(sql,('webmaster@python.org','very-secret'))

    # connection is not autocommit by default. So you must commit to save
    # your changes.
    connection.commit()
finally:
    connection.close()